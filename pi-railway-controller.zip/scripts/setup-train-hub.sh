#!/usr/bin/env bash
#
# setup-train-hub.sh
#
# Configures a fresh Raspberry Pi OS (Bookworm) as:
#   - WiFi access point: SSID "ChangeMe123!"
#   - Local DHCP + DNS server for connected trains (via dnsmasq)
#   - Node.js 22.x runtime
#
# Tested against Raspberry Pi OS Bookworm, which uses NetworkManager
# by default. Run as root (sudo) on the Pi itself, not over SSH on
# wlan0 (you'll lose the connection when wlan0 becomes the AP).
#
# Usage:
#   chmod +x setup-train-hub.sh
#   sudo ./setup-train-hub.sh
#
set -euo pipefail

SSID="PiRailwayController"
PASSWORD="ChangeMe123!"
AP_IFACE="wlan0"
AP_IP="192.168.4.1"
AP_SUBNET="192.168.4.0/24"
AP_DHCP_RANGE_START="192.168.4.10"
AP_DHCP_RANGE_END="192.168.4.100"
CON_NAME="train-hub-ap"
NODE_MAJOR="22"

if [[ $EUID -ne 0 ]]; then
  echo "Please run as root: sudo ./setup-train-hub.sh" >&2
  exit 1
fi

echo "==> Updating package lists"
apt-get update

echo "==> Installing dependencies (dnsmasq, NetworkManager tools, curl)"
apt-get install -y dnsmasq network-manager curl

# ---------------------------------------------------------------------------
# 1. Access point via NetworkManager (nmcli)
#    Raspberry Pi OS Bookworm manages wifi through NetworkManager, so we
#    define the AP as a NetworkManager connection profile rather than
#    using the older hostapd/dhcpcd combo.
# ---------------------------------------------------------------------------
echo "==> Configuring access point '${SSID}' on ${AP_IFACE}"

# Remove any pre-existing profile with the same name so this script is
# safe to re-run.
nmcli connection delete "${CON_NAME}" 2>/dev/null || true

nmcli connection add \
  type wifi \
  ifname "${AP_IFACE}" \
  con-name "${CON_NAME}" \
  autoconnect yes \
  ssid "${SSID}"

nmcli connection modify "${CON_NAME}" \
  802-11-wireless.mode ap \
  802-11-wireless.band bg \
  ipv4.method manual \
  ipv4.addresses "${AP_IP}/24" \
  ipv6.method disabled \
  wifi-sec.key-mgmt wpa-psk \
  wifi-sec.psk "${PASSWORD}"

# We'll let dnsmasq handle DHCP+DNS instead of NetworkManager's built-in
# shared-mode dnsmasq, so keep NM's ipv4 method as "manual" (static IP
# only, no NM-managed DHCP server) — done above.

echo "==> Bringing up the access point"
nmcli connection up "${CON_NAME}"

# ---------------------------------------------------------------------------
# 2. dnsmasq: DHCP + DNS for clients on the AP subnet
# ---------------------------------------------------------------------------
echo "==> Configuring dnsmasq"

# Stop the service while we edit config
systemctl stop dnsmasq || true

# Back up the original config once
if [[ -f /etc/dnsmasq.conf && ! -f /etc/dnsmasq.conf.orig ]]; then
  cp /etc/dnsmasq.conf /etc/dnsmasq.conf.orig
fi

cat > /etc/dnsmasq.d/train-hub.conf <<EOF
# --- train-hub AP config ---
interface=${AP_IFACE}
bind-interfaces
domain-needed
bogus-priv

# DHCP range for connected trains/clients
dhcp-range=${AP_DHCP_RANGE_START},${AP_DHCP_RANGE_END},255.255.255.0,12h

# Local DNS: resolve hub itself, forward everything else upstream
address=/train-hub.local/${AP_IP}
EOF

systemctl unmask dnsmasq || true
systemctl enable dnsmasq
systemctl restart dnsmasq

# ---------------------------------------------------------------------------
# 3. IP forwarding is intentionally left OFF. If you later want the Pi to
#    route AP clients out to the internet via eth0, uncomment below and
#    add the appropriate iptables/nftables NAT rules.
# ---------------------------------------------------------------------------
# echo "net.ipv4.ip_forward=1" >> /etc/sysctl.conf
# sysctl -p

# ---------------------------------------------------------------------------
# 4. Node.js via NodeSource
# ---------------------------------------------------------------------------
# echo "==> Installing Node.js ${NODE_MAJOR}.x"
# curl -fsSL "https://deb.nodesource.com/setup_${NODE_MAJOR}.x" | bash -
# apt-get install -y nodejs

# echo "==> Versions installed:"
# node -v
# npm -v

echo ""
echo "======================================================================"
echo " Done."
echo " AP SSID:      ${SSID}"
echo " AP password:  ${PASSWORD}"
echo " Hub address:  ${AP_IP} (train-hub.local)"
echo " DHCP range:   ${AP_DHCP_RANGE_START} - ${AP_DHCP_RANGE_END}"
echo " Node.js:      $(node -v)"
echo "======================================================================"